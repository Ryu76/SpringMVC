package com.myspring.util;


public class ExceptionHandle {

}
