package com.myspring.domain;

public class SumVO {

}
