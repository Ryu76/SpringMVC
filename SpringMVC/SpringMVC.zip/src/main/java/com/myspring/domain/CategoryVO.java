package com.myspring.domain;

public class CategoryVO {
	
	private int cg_num;
	private String cg_code;
	private String cg_name;
	
	public int getCg_num() {
		return cg_num;
	}
	public void setCg_num(int cg_num) {
		this.cg_num = cg_num;
	}
	public String getCg_code() {
		return cg_code;
	}
	public void setCg_code(String cg_code) {
		this.cg_code = cg_code;
	}
	public String getCg_name() {
		return cg_name;
	}
	public void setCg_name(String cg_name) {
		this.cg_name = cg_name;
	}
	
	

}
