package board.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import common.controller.AbstractAction;
import board.model.*;

public class BoardFormAction extends AbstractAction {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		BoardDAOMyBatis dao=new BoardDAOMyBatis();
		
		int cnt=dao.getTotalCount();
		
		req.setAttribute("count", cnt);
		
		this.setViewPage("/board/boardWrite.jsp");
		this.setRedirect(false);
	}

}
